#include <stdlib.h>
#include <pthread.h>
#include "sbuffer.h"

// =============== sbuffer_init ===============
int sbuffer_init(sbuffer_t **buffer) {
    if (buffer == NULL) return SBUFFER_FAILURE;

    *buffer = malloc(sizeof(sbuffer_t));
    if (*buffer == NULL) return SBUFFER_FAILURE;

    (*buffer)->head = NULL;
    (*buffer)->tail = NULL;
    (*buffer)->end_of_stream = 0;

    pthread_mutex_init(&(*buffer)->mutex, NULL);
    pthread_cond_init(&(*buffer)->condvar, NULL);

    return SBUFFER_SUCCESS;
}

// =============== sbuffer_free ===============
int sbuffer_free(sbuffer_t **buffer) {
    if (buffer == NULL || *buffer == NULL) return SBUFFER_FAILURE;

    sbuffer_node_t *current = (*buffer)->head;
    while (current != NULL) {
        sbuffer_node_t *next = current->next;
        free(current);
        current = next;
    }

    pthread_mutex_destroy(&(*buffer)->mutex);
    pthread_cond_destroy(&(*buffer)->condvar);

    free(*buffer);
    *buffer = NULL;
    return SBUFFER_SUCCESS;
}

// =============== sbuffer_insert ===============
// 每插入一条数据时，将 consumer_flags=0
int sbuffer_insert(sbuffer_t *buffer, sensor_data_t *data) {
    if (buffer == NULL || data == NULL) return SBUFFER_FAILURE;

    sbuffer_node_t *new_node = malloc(sizeof(sbuffer_node_t));
    if (new_node == NULL) return SBUFFER_FAILURE;

    new_node->data = *data;
    new_node->next = NULL;
    // 新增：初始时，还没有任何消费者读取过
    new_node->consumer_flags = 0;

    pthread_mutex_lock(&buffer->mutex);

    if (buffer->tail == NULL) {
        // 缓冲区为空
        buffer->head = buffer->tail = new_node;
    } else {
        // 添加到尾部
        buffer->tail->next = new_node;
        buffer->tail = new_node;
    }

    // 通知等待线程：有新数据
    pthread_cond_broadcast(&buffer->condvar);
    pthread_mutex_unlock(&buffer->mutex);

    return SBUFFER_SUCCESS;
}

// =============== sbuffer_remove ===============
// 多消费者版本
// consumer_id 用于区分是哪一个消费者(如 CONSUMER_DATAMGR, CONSUMER_STORAGEMGR)
// 返回 SBUFFER_SUCCESS 表示取到了数据
// 返回 SBUFFER_NO_DATA 表示当前没有尚未被本消费者读取的数据，且流也结束了
// 返回 SBUFFER_FAILURE 其他错误
int sbuffer_remove(sbuffer_t *buffer, sensor_data_t *data, int consumer_id) {
    if (buffer == NULL || data == NULL) return SBUFFER_FAILURE;

    pthread_mutex_lock(&buffer->mutex);

    // 若队列空且流未结束 => 等待
    while (buffer->head == NULL && buffer->end_of_stream == 0) {
        pthread_cond_wait(&buffer->condvar, &buffer->mutex);
    }

    // 如果此时队列依旧空，但流已结束 => 没有数据可取
    if (buffer->head == NULL) {
        pthread_mutex_unlock(&buffer->mutex);
        return SBUFFER_NO_DATA;
    }

    // 遍历链表，寻找第一个“尚未被本消费者读取”的节点
    // 如果找到了，就标记并根据情况删除节点
    sbuffer_node_t *prev = NULL;
    sbuffer_node_t *curr = buffer->head;

    while (curr != NULL) {
        // 检查本消费者是否已经读取过
        // 只要 (curr->consumer_flags & consumer_id)==0，表示还没被本消费者读过
        if ((curr->consumer_flags & consumer_id) == 0) {
            // 1) 拷贝数据
            *data = curr->data;

            // 2) 标记本消费者读过
            curr->consumer_flags |= consumer_id;

            // 3) 如果已被两个消费者都读过，就删除
            // 假设只有 Data Manager(0x01) & Storage Manager(0x02)
            int all_consumed = (CONSUMER_DATAMGR | CONSUMER_STORAGEMGR);
            if (curr->consumer_flags == all_consumed) {
                // 移除节点
                sbuffer_node_t *to_remove = curr;
                if (prev == NULL) {
                    // 移除头节点
                    buffer->head = curr->next;
                    if (buffer->head == NULL) {
                        buffer->tail = NULL;
                    }
                } else {
                    prev->next = curr->next;
                    if (prev->next == NULL) {
                        buffer->tail = prev;
                    }
                }
                curr = curr->next;
                free(to_remove);

            } else {
                // 如果没有全部消费者读完，则保留节点
                prev = curr;
                curr = curr->next;
            }

            pthread_mutex_unlock(&buffer->mutex);
            return SBUFFER_SUCCESS;
        } else {
            // 本消费者已经读过 => 跳过到下一个节点
            prev = curr;
            curr = curr->next;
        }
    }

    // 如果遍历完都没找到可读的数据
    // 若流结束 => NO_DATA
    // 否则 => 也可NO_DATA(或者等待)
    if (buffer->end_of_stream) {
        pthread_mutex_unlock(&buffer->mutex);
        return SBUFFER_NO_DATA;
    } else {
        // 这里可以选择继续等待，也可以直接返回 NO_DATA
        pthread_mutex_unlock(&buffer->mutex);
        return SBUFFER_NO_DATA;
    }
}

// =============== sbuffer_end_stream ===============
void sbuffer_end_stream(sbuffer_t *buffer) {
    pthread_mutex_lock(&buffer->mutex);
    buffer->end_of_stream = 1;
    // 通知所有等待线程
    pthread_cond_broadcast(&buffer->condvar);
    pthread_mutex_unlock(&buffer->mutex);
}

// =============== sbuffer_is_stream_ended ===============
int sbuffer_is_stream_ended(sbuffer_t *buffer) {
    int is_ended;

    pthread_mutex_lock(&buffer->mutex);
    is_ended = buffer->end_of_stream;
    pthread_mutex_unlock(&buffer->mutex);

    return is_ended;
}
