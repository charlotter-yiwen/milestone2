
#ifndef _SBUFFER_H_
#define _SBUFFER_H_

#include "config.h"
#include <pthread.h>

#define SBUFFER_FAILURE -1
#define SBUFFER_SUCCESS 0
#define SBUFFER_NO_DATA 1

// 给 2 个消费者分别定义标识位
#define CONSUMER_DATAMGR    (1 << 0)  // 0x01
#define CONSUMER_STORAGEMGR (1 << 1)  // 0x02

// sbuffer_node 的结构里要加 consumer_flags
typedef struct sbuffer_node {
    sensor_data_t data;              // 原始传感器数据
    struct sbuffer_node *next;       // 单向链表指针

    // 新增：标记哪些消费者已经读取过这条数据
    int consumer_flags;
} sbuffer_node_t;

typedef struct sbuffer {
    sbuffer_node_t *head;
    sbuffer_node_t *tail;
    pthread_mutex_t mutex;
    pthread_cond_t  condvar;
    int end_of_stream;
} sbuffer_t;

//typedef struct sbuffer sbuffer_t;

/**
 * Allocates and initializes a new shared buffer
 * \param buffer a double pointer to the buffer that needs to be initialized
 * \return SBUFFER_SUCCESS on success and SBUFFER_FAILURE if an error occurred
 */
int sbuffer_init(sbuffer_t **buffer);

/**
 * All allocated resources are freed and cleaned up
 * \param buffer a double pointer to the buffer that needs to be freed
 * \return SBUFFER_SUCCESS on success and SBUFFER_FAILURE if an error occurred
 */
int sbuffer_free(sbuffer_t **buffer);

/**
 * Removes the first sensor data in 'buffer' (at the 'head') and returns this sensor data as '*data'
 * If 'buffer' is empty, the function doesn't block until new sensor data becomes available but returns SBUFFER_NO_DATA
 * \param buffer a pointer to the buffer that is used
 * \param data a pointer to pre-allocated sensor_data_t space, the data will be copied into this structure. No new memory is allocated for 'data' in this function.
 * \return SBUFFER_SUCCESS on success and SBUFFER_FAILURE if an error occurred
 */
//int sbuffer_remove(sbuffer_t *buffer, sensor_data_t *data);
int sbuffer_remove(sbuffer_t *buffer, sensor_data_t *data, int consumer_flag);

/**
 * Inserts the sensor data in 'data' at the end of 'buffer' (at the 'tail')
 * \param buffer a pointer to the buffer that is used
 * \param data a pointer to sensor_data_t data, that will be copied into the buffer
 * \return SBUFFER_SUCCESS on success and SBUFFER_FAILURE if an error occured
*/
int sbuffer_insert(sbuffer_t *buffer, sensor_data_t *data);
void sbuffer_end_stream(sbuffer_t *buffer);
/**
 * Checks if the end-of-stream flag is set for the buffer.
 * \param buffer A pointer to the shared buffer
 * \return 1 if the stream has ended, 0 otherwise
 */
int sbuffer_is_stream_ended(sbuffer_t *buffer);


#endif  //_SBUFFER_H_
