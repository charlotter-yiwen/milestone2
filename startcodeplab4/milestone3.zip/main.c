#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include "sbuffer.h"

// 全局变量
sbuffer_t *shared_buffer;  // 共享缓冲区

// 写线程函数
void *writer_thread(void *arg) {
    FILE *file = fopen("sensor_data", "rb");  // 二进制读取
    if (!file) {
        perror("Failed to open sensor_data file");
        return NULL;
    }

    sensor_data_t data;
    while (fread(&data, sizeof(sensor_data_t), 1, file) == 1) {  // 按结构体逐条读取
        sbuffer_insert(shared_buffer, &data);
        printf("Writer: Inserted id=%hu, value=%.2f, ts=%ld\n", data.id, data.value, data.ts);
        usleep(10000);  // 每10毫秒插入一次
    }

    // 插入结束标记
    data.id = 0;  // 表示结束
    sbuffer_insert(shared_buffer, &data);
    printf("Writer: Inserted end-of-stream marker\n");

    fclose(file);
    return NULL;
}

// 读线程函数
void *reader_thread(void *arg) {
    int thread_id = *(int *)arg;  // 获取线程ID
    char filename[64];
    snprintf(filename, sizeof(filename), "sensor_data_out%d.csv", thread_id);  // 生成独立文件名

    FILE *file = fopen(filename, "w");
    if (!file) {
        perror("Failed to open output file");
        return NULL;
    }

    fprintf(file, "sensor_id,temperature,timestamp\n");  // 写入CSV表头

    sensor_data_t data;
    while (1) {
        if (sbuffer_remove(shared_buffer, &data) == SBUFFER_NO_DATA) {
            // 检测到结束标记，退出循环
            break;
        }
        fprintf(file, "%hu,%.2f,%ld\n", data.id, data.value, data.ts);
        printf("Reader %d: Removed id=%hu, value=%.2f, ts=%ld\n", thread_id, data.id, data.value, data.ts);
        usleep(25000);  // 每25毫秒处理一次
    }

    fclose(file);
    printf("Reader %d: Finished processing.\n", thread_id);
    return NULL;
}

// 主函数
int main() {
    pthread_t writer, reader1, reader2;

    // 初始化共享缓冲区
    if (sbuffer_init(&shared_buffer) != SBUFFER_SUCCESS) {
        fprintf(stderr, "Failed to initialize buffer\n");
        return EXIT_FAILURE;
    }

    // 创建线程ID
    int reader1_id = 1;
    int reader2_id = 2;

    // 创建写线程和读线程
    pthread_create(&writer, NULL, writer_thread, NULL);
    pthread_create(&reader1, NULL, reader_thread, &reader1_id);
    pthread_create(&reader2, NULL, reader_thread, &reader2_id);

    // 等待所有线程结束
    pthread_join(writer, NULL);
    pthread_join(reader1, NULL);
    pthread_join(reader2, NULL);

    // 清理共享缓冲区
    sbuffer_free(&shared_buffer);

    printf("All threads finished successfully.\n");
    return EXIT_SUCCESS;
}
