#include <stdlib.h>
#include <pthread.h>
#include "sbuffer.h"

// 节点结构定义
typedef struct sbuffer_node {
    struct sbuffer_node *next;  // 指向下一个节点
    sensor_data_t data;         // 存储传感器数据
} sbuffer_node_t;

// 缓冲区结构定义
struct sbuffer {
    sbuffer_node_t *head;       // 缓冲区头节点
    sbuffer_node_t *tail;       // 缓冲区尾节点
    pthread_mutex_t mutex;      // 互斥锁
    pthread_cond_t cond;        // 条件变量
    int active_readers;         // 活跃 Reader 数量
};

// 初始化缓冲区
int sbuffer_init(sbuffer_t **buffer) {
    *buffer = malloc(sizeof(sbuffer_t));
    if (*buffer == NULL) return SBUFFER_FAILURE;

    (*buffer)->head = NULL;
    (*buffer)->tail = NULL;
    (*buffer)->active_readers = 2;  // 默认有两个 Reader

    pthread_mutex_init(&(*buffer)->mutex, NULL);
    pthread_cond_init(&(*buffer)->cond, NULL);

    return SBUFFER_SUCCESS;
}

// 释放缓冲区
int sbuffer_free(sbuffer_t **buffer) {
    if (buffer == NULL || *buffer == NULL) return SBUFFER_FAILURE;

    sbuffer_node_t *temp;
    while ((*buffer)->head != NULL) {
        temp = (*buffer)->head;
        (*buffer)->head = (*buffer)->head->next;
        free(temp);
    }

    pthread_mutex_destroy(&(*buffer)->mutex);
    pthread_cond_destroy(&(*buffer)->cond);

    free(*buffer);
    *buffer = NULL;

    return SBUFFER_SUCCESS;
}

// 插入数据
int sbuffer_insert(sbuffer_t *buffer, sensor_data_t *data) {
    if (buffer == NULL) return SBUFFER_FAILURE;

    sbuffer_node_t *node = malloc(sizeof(sbuffer_node_t));
    if (node == NULL) return SBUFFER_FAILURE;

    node->data = *data;
    node->next = NULL;

    pthread_mutex_lock(&buffer->mutex);

    if (buffer->tail == NULL) {  // 如果缓冲区为空
        buffer->head = buffer->tail = node;
    } else {  // 如果缓冲区不为空
        buffer->tail->next = node;
        buffer->tail = node;
    }

    pthread_cond_broadcast(&buffer->cond);  // 通知所有等待的 Reader
    pthread_mutex_unlock(&buffer->mutex);

    return SBUFFER_SUCCESS;
}

// 移除数据
int sbuffer_remove(sbuffer_t *buffer, sensor_data_t *data) {
    if (buffer == NULL) return SBUFFER_FAILURE;

    pthread_mutex_lock(&buffer->mutex);

    // 等待缓冲区中有数据
    while (buffer->head == NULL) {
        pthread_cond_wait(&buffer->cond, &buffer->mutex);
    }

    sbuffer_node_t *temp = buffer->head;
    *data = temp->data;

    // 检测是否是结束标记
    if (data->id == 0) {
        buffer->active_readers--;  // 活跃 Reader 数量减一
        if (buffer->active_readers == 0) {
            // 所有 Reader 都检测到结束标记，移除结束标记节点
            buffer->head = buffer->head->next;
            if (buffer->head == NULL) buffer->tail = NULL;
            free(temp);
        }
        pthread_mutex_unlock(&buffer->mutex);
        return SBUFFER_NO_DATA;  // 返回结束标记状态
    }

    // 如果不是结束标记，移除头节点
    buffer->head = buffer->head->next;
    if (buffer->head == NULL) buffer->tail = NULL;
    free(temp);

    pthread_mutex_unlock(&buffer->mutex);
    return SBUFFER_SUCCESS;
}
