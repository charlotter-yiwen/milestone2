#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>

#define NUM_RECORDS 100  // 要生成的记录数

typedef struct {
    uint16_t sensor_id;   // 传感器ID
    double temperature;   // 温度值
    time_t timestamp;     // 时间戳
} sensor_data_t;

void generate_sensor_data(const char *filename) {
    FILE *file = fopen(filename, "wb");
    if (!file) {
        perror("Failed to open file for writing");
        exit(EXIT_FAILURE);
    }

    srand(time(NULL));  // 初始化随机数种子

    for (int i = 0; i < NUM_RECORDS; i++) {
        sensor_data_t data;

        // 随机生成传感器数据
        data.sensor_id = rand() % 100 + 1;                 // 随机传感器ID (1到100)
        data.temperature = (rand() % 3000) / 100.0 + 15.0; // 随机温度值 (15.0 到 45.0)
        data.timestamp = time(NULL) + i * 60;             // 时间戳间隔1分钟

        // 写入二进制文件
        fwrite(&data, sizeof(sensor_data_t), 1, file);
    }

    fclose(file);
    printf("Sensor data generated successfully in '%s'.\n", filename);
}

int main() {
    const char *filename = "sensor_data";  // 输出文件名
    generate_sensor_data(filename);
    return 0;
}
