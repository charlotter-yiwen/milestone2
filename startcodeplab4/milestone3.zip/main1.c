#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include "sbuffer.h"

// 全局变量
sbuffer_t *shared_buffer;
FILE *shared_file;
pthread_mutex_t file_mutex;

// 写线程函数
void *writer_thread(void *arg) {
    FILE *file = fopen("sensor_data", "rb");
    if (!file) {
        perror("Failed to open sensor_data file");
        return NULL;
    }

    sensor_data_t data;
    while (fread(&data, sizeof(sensor_data_t), 1, file) == 1) {
        sbuffer_insert(shared_buffer, &data);
        printf("Writer: Inserted id=%hu, value=%.2f, ts=%ld\n", data.id, data.value, data.ts);
        usleep(10000);  // 每 10 毫秒插入一次
    }

    // 插入结束标记
    data.id = 0;
    sbuffer_insert(shared_buffer, &data);
    printf("Writer: Inserted end-of-stream marker\n");

    fclose(file);
    return NULL;
}

// 读线程函数
void *reader_thread(void *arg) {
    sensor_data_t data;

    while (1) {
        sbuffer_remove(shared_buffer, &data);
        if (data.id == 0) break;

        pthread_mutex_lock(&file_mutex);
        fprintf(shared_file, "%hu,%.2f,%ld\n", data.id, data.value, data.ts);
        pthread_mutex_unlock(&file_mutex);

        printf("Reader: Removed id=%hu, value=%.2f, ts=%ld\n", data.id, data.value, data.ts);
        usleep(25000);  // 每 25 毫秒处理一次
    }

    return NULL;
}

int main() {
    pthread_t writer, reader1, reader2;

    // 初始化缓冲区
    if (sbuffer_init(&shared_buffer) != SBUFFER_SUCCESS) {
        fprintf(stderr, "Failed to initialize buffer\n");
        return EXIT_FAILURE;
    }

    // 初始化文件和互斥锁
    shared_file = fopen("sensor_data_out.csv", "w");
    if (!shared_file) {
        perror("Failed to open sensor_data_out.csv");
        return EXIT_FAILURE;
    }
    pthread_mutex_init(&file_mutex, NULL);

    // 写入 CSV 表头
    fprintf(shared_file, "sensor_id,temperature,timestamp\n");

    // 创建线程
    pthread_create(&writer, NULL, writer_thread, NULL);
    pthread_create(&reader1, NULL, reader_thread, NULL);
    pthread_create(&reader2, NULL, reader_thread, NULL);

    // 等待线程结束
    pthread_join(writer, NULL);
    pthread_join(reader1, NULL);
    pthread_join(reader2, NULL);

    // 清理资源
    fclose(shared_file);
    pthread_mutex_destroy(&file_mutex);
    sbuffer_free(&shared_buffer);

    printf("All threads finished successfully.\n");
    return EXIT_SUCCESS;
}
