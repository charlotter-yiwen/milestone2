#include <stdio.h>
#include <stdint.h>
#include <time.h>

typedef struct {
    uint16_t sensor_id;
    double temperature;
    time_t timestamp;
} sensor_data_t;

int main() {
    const char *filename = "sensor_data";
    FILE *file = fopen(filename, "rb");
    if (!file) {
        perror("Failed to open sensor_data file");
        return 1;
    }

    sensor_data_t data;
    while (fread(&data, sizeof(sensor_data_t), 1, file)) {
        printf("Sensor ID: %u, Temperature: %.2f, Timestamp: %ld\n",
               data.sensor_id, data.temperature, data.timestamp);
    }

    fclose(file);
    return 0;
}
