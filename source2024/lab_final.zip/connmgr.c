#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <pthread.h>
#include "lib/tcpsock.h"
#include "sbuffer.h"
#include "config.h"

#ifndef TIMEOUT
#define TIMEOUT 10
#endif

// 全局变量
pthread_mutex_t mutex_monitor;
int active_connections = 0;
int MAX_CONN;
int PORT;
sbuffer_t *buffer;

// 日志记录函数
int write_to_log_process(char *msg) {
    printf("%s\n", msg); // 在这里实现日志记录逻辑，比如写入文件或终端
    return 0;
}

typedef struct conn {
    tcpsock_t *client_socket;
    bool receive_msg;
    bool timeout;
    sensor_id_t sensorID;
} conn_t;

void send_end_of_stream() {
    printf("Sending end-of-stream signal\n");
    sensor_data_t data;
    data.id = 0;
    sbuffer_insert(buffer, &data);
}

void *monitor_thread(void *arg) {
    conn_t *conn = (conn_t *)arg;
    sleep(TIMEOUT);
    if (!conn->receive_msg) {
        pthread_mutex_lock(&mutex_monitor);
        tcp_close(&(conn->client_socket));
        conn->timeout = true;
        char msg[100];
        snprintf(msg, sizeof(msg), "TCP connection closed from sensor %hu (TIMEOUT)", conn->sensorID);
        write_to_log_process(msg);
        pthread_mutex_unlock(&mutex_monitor);
    }
    return NULL;
}

void *listen_to_sensor_node(void *arg) {
    tcpsock_t *client_socket = (tcpsock_t *)arg;
    pthread_t monitor_tid;

    conn_t conn;
    conn.client_socket = client_socket;
    conn.receive_msg = false;
    conn.timeout = false;
    conn.sensorID = 0;

    sensor_data_t data;
    int bytes, status;

    pthread_create(&monitor_tid, NULL, monitor_thread, &conn);

    while (1) {
        bytes = sizeof(data.id);
        status = tcp_receive(client_socket, &data.id, &bytes);
        if (status != TCP_NO_ERROR || bytes == 0) break;

        bytes = sizeof(data.value);
        status = tcp_receive(client_socket, &data.value, &bytes);
        if (status != TCP_NO_ERROR || bytes == 0) break;

        bytes = sizeof(data.ts);
        status = tcp_receive(client_socket, &data.ts, &bytes);
        if (status != TCP_NO_ERROR || bytes == 0) break;

        pthread_mutex_lock(&mutex_monitor);
        conn.receive_msg = true;
        pthread_mutex_unlock(&mutex_monitor);

        if (conn.sensorID == 0) {
            conn.sensorID = data.id;
            char msg[100];
            snprintf(msg, sizeof(msg), "Sensor node %hu has opened a new connection.", conn.sensorID);
            write_to_log_process(msg);
        }

        sbuffer_insert(buffer, &data);
    }

    pthread_cancel(monitor_tid);
    pthread_join(monitor_tid, NULL);

    if (conn.timeout) {
        char msg[100];
        snprintf(msg, sizeof(msg), "Sensor node %hu connection closed due to timeout.", conn.sensorID);
        write_to_log_process(msg);
    } else {
        char msg[100];
        snprintf(msg, sizeof(msg), "Sensor node %hu connection closed.", conn.sensorID);
        write_to_log_process(msg);
        tcp_close(&client_socket);
    }

    pthread_mutex_lock(&mutex_monitor);
    active_connections--;
    pthread_mutex_unlock(&mutex_monitor);

    return NULL;
}

void connmgr_listen() {
    pthread_mutex_init(&mutex_monitor, NULL);

    tcpsock_t *server_socket, *client_socket;
    pthread_t thread_id;

    if (tcp_passive_open(&server_socket, PORT) != TCP_NO_ERROR) {
        fprintf(stderr, "Error: Unable to open server socket on port %d\n", PORT);
        exit(EXIT_FAILURE);
    }

    printf("Listening for connections on port %d...\n", PORT);
    write_to_log_process("Server started.");

    while (active_connections < MAX_CONN) {
        if (tcp_wait_for_connection(server_socket, &client_socket) != TCP_NO_ERROR) {
            fprintf(stderr, "Error: Failed to accept connection\n");
            continue;
        }

        pthread_mutex_lock(&mutex_monitor);
        active_connections++;
        pthread_mutex_unlock(&mutex_monitor);

        if (pthread_create(&thread_id, NULL, listen_to_sensor_node, client_socket) != 0) {
            fprintf(stderr, "Error: Failed to create thread for new client\n");
            tcp_close(&client_socket);
            pthread_mutex_lock(&mutex_monitor);
            active_connections--;
            pthread_mutex_unlock(&mutex_monitor);
        } else {
            pthread_detach(thread_id);
        }
    }

    send_end_of_stream();

    tcp_close(&server_socket);
    pthread_mutex_destroy(&mutex_monitor);
    printf("Server shutting down.\n");
    write_to_log_process("Server shut down.");
}