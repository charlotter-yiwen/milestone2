//pass
#include "sensor_db.h"
#include <pthread.h>
#include <stdbool.h>

// Shared database file pointer
static FILE *db_file = NULL;
// Mutex for thread-safe file operations
static pthread_mutex_t db_mutex = PTHREAD_MUTEX_INITIALIZER;

// Open the database file
FILE *open_db(char *filename, bool append) {
    pthread_mutex_lock(&db_mutex);
    if (append) {
        db_file = fopen(filename, "a");
    } else {
        db_file = fopen(filename, "w");
        if (db_file) {
            fprintf(stderr, "A new data.csv file has been created.\n");
        }
    }
    if (!db_file) {
        fprintf(stderr, "Error: Could not open the file %s\n", filename);
    }
    pthread_mutex_unlock(&db_mutex);
    return db_file;
}

// Insert a sensor record into the database
int insert_sensor(sensor_id_t id, sensor_value_t value, sensor_ts_t ts) {
    pthread_mutex_lock(&db_mutex);
    if (!db_file) {
        fprintf(stderr, "Database file is not open.\n");
        pthread_mutex_unlock(&db_mutex);
        return -1;
    }

    fprintf(db_file, "%u, %f, %ld\n", id, value, ts);
    fflush(db_file); // Ensure data is written to disk immediately
    fprintf(stderr, "Data insertion from sensor %u succeeded.\n", id);

    pthread_mutex_unlock(&db_mutex);
    return 0;
}

// Close the database file
int close_db() {
    pthread_mutex_lock(&db_mutex);
    if (!db_file) {
        fprintf(stderr, "Database file is not open.\n");
        pthread_mutex_unlock(&db_mutex);
        return -1;
    }

    fclose(db_file);
    db_file = NULL;
    fprintf(stderr, "The data.csv file has been closed.\n");
    pthread_mutex_unlock(&db_mutex);
    return 0;
}

// Storage manager thread function
void *create_storagemgr(void *ptr) {
    sbuffer_t *buffer = (sbuffer_t *)ptr;
    if (!buffer) {
        fprintf(stderr, "Shared buffer is NULL.\n");
        pthread_exit(NULL);
    }

    // Open the database file
    if (!open_db("data.csv", false)) {
        pthread_exit(NULL);
    }

    sensor_data_t data;
    int result;

   while (1) {
    result = sbuffer_remove(buffer, &data);
//when test new add
   if (result == SBUFFER_NO_DATA) {
    // 检查数据流是否结束
    if (sbuffer_is_stream_ended(buffer)) {
        printf("[Consumer] No more data to consume. Exiting...\n");
        break;
    }
    continue;
}

}


    close_db(); // Close the database file
    pthread_exit(NULL);
}
