#include "sensor_db.h"
#include <pthread.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define _POSIX_C_SOURCE 200809L
#include <unistd.h>




// ========== 外部函数：写日志到 Log 进程 ==========
extern int write_to_log_process(char *msg);

// ========== 全局/静态变量 ==========
// 供写 CSV 的文件指针
static FILE *db_file = NULL;

// 互斥锁，确保多线程对 db_file 操作安全
static pthread_mutex_t db_mutex = PTHREAD_MUTEX_INITIALIZER;

// ========== 工具函数：获取当前时间字符串 ==========
char *get_current_time_string() {
    static char time_str[32];
    time_t now = time(NULL);
    struct tm *tm_info = localtime(&now);
    strftime(time_str, sizeof(time_str), "%a %b %d %H:%M:%S %Y", tm_info);
    return time_str;
}

// ========== 打开数据库文件 ==========
// append = false 时表示要新建/覆盖 data.csv
FILE *open_db(char *filename, bool append) {
    pthread_mutex_lock(&db_mutex);

    if (append) {
        db_file = fopen(filename, "a");
    } else {
        db_file = fopen(filename, "w");
        if (db_file) {
            // 通过日志进程记录：新 data.csv 文件已被创建
            write_to_log_process("A new data.csv file has been created.");
        }
    }

    if (!db_file) {
        fprintf(stderr, "Error: Could not open the file %s\n", filename);
        pthread_mutex_unlock(&db_mutex);
        return NULL;
    } else {
        // 可选：也可以记录 "Database file data.csv opened."
        char msg[128];
        snprintf(msg, sizeof(msg),
                 "Database file %s opened.", filename);
        write_to_log_process(msg);
    }

    pthread_mutex_unlock(&db_mutex);
    return db_file;
}

// ========== 插入一条传感器记录到 CSV ==========
// 返回 0 表示成功；-1 表示失败
int insert_sensor(sensor_id_t id, sensor_value_t value, sensor_ts_t ts) {
    pthread_mutex_lock(&db_mutex);

    // 如果想过滤 id=0，可在此处直接返回
    if (id == 0) {
        pthread_mutex_unlock(&db_mutex);
        return -1;
    }

    if (!db_file) {
        fprintf(stderr, "Database file is not open.\n");
        pthread_mutex_unlock(&db_mutex);
        return -1;
    }

    // 写入 CSV
    fprintf(db_file, "%u, %.2f, %ld\n", id, value, ts);
    fflush(db_file);  // 确保立刻写入磁盘

    // 通过日志进程记录：Data insertion succeeded
    char log_msg[100];
    snprintf(log_msg, sizeof(log_msg),
             "Data insertion from sensor %u succeeded.", id);
    write_to_log_process(log_msg);

    pthread_mutex_unlock(&db_mutex);
    return 0;
}

// ========== 关闭数据库文件 ==========
// 返回 0 表示成功；-1 表示失败
int close_db() {
    pthread_mutex_lock(&db_mutex);
    if (!db_file) {
        fprintf(stderr, "Database file is not open.\n");
        pthread_mutex_unlock(&db_mutex);
        return -1;
    }

    fclose(db_file);
    db_file = NULL;

    // 记录“data.csv file has been closed.”
    write_to_log_process("The data.csv file has been closed.");

    pthread_mutex_unlock(&db_mutex);
    return 0;
}

// ========== Storage Manager 线程函数 ==========
// 从 sbuffer 中不断读取数据，写入 CSV，直到检测到结束信号
void *create_storagemgr(void *ptr) {
    sbuffer_t *buffer = (sbuffer_t *)ptr;
    if (!buffer) {
        fprintf(stderr, "Error: Shared buffer is NULL.\n");
        pthread_exit(NULL);
    }

    // 打开数据库文件（覆盖模式）
    if (!open_db("data.csv", false)) {
        fprintf(stderr, "Error: Failed to open database. Exiting storage manager thread.\n");
        pthread_exit(NULL);
    }

    // 循环从 sbuffer 移除数据
    sensor_data_t data;
    while (true) {
        int result = sbuffer_remove(buffer, &data);

        if (result == SBUFFER_NO_DATA) {
            // 没数据？检查流是否已结束
            if (sbuffer_is_stream_ended(buffer)) {
                printf("[StorageMgr] No more data to consume. Exiting...\n");
                break;
            }
            // 若流没结束，稍微等一下再继续
            // 也可直接 continue
            //usleep(100000); // 100 ms
            continue;
        }

        if (result == SBUFFER_SUCCESS) {
            // 如果 id=0 代表结束标志，就 break
            if (data.id == 0) {
                break;
            }
            // 否则插入到 CSV
            insert_sensor(data.id, data.value, data.ts);
        } else {
            // SBUFFER_FAILURE 等情况
            break;
        }
    }

    close_db(); // 关闭 CSV 文件
    pthread_exit(NULL);
}

/**
 *26 noon
 *#include "sensor_db.h"
#include <pthread.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Shared database file pointer
static FILE *db_file = NULL;
static FILE *gateway_log = NULL; // Log file pointer for gateway.log

// Mutex for thread-safe file operations
static pthread_mutex_t db_mutex = PTHREAD_MUTEX_INITIALIZER;

// Function to get current time as a string
char *get_current_time_string() {
    static char time_str[32];
    time_t now = time(NULL);
    struct tm *tm_info = localtime(&now);
    strftime(time_str, sizeof(time_str), "%a %b %d %H:%M:%S %Y", tm_info);
    return time_str;
}

// Open the database file
// Open the database file
FILE *open_db(char *filename, bool append) {
    pthread_mutex_lock(&db_mutex);
    if (append) {
        db_file = fopen(filename, "a");
    } else {
        db_file = fopen(filename, "w");
        if (db_file) {
            fprintf(stderr, "A new data.csv file has been created.\n");
        }
    }

    if (!db_file) {
        fprintf(stderr, "Error: Could not open the file %s\n", filename);
    } else {
        // Open the log file
        if (!gateway_log) {
            gateway_log = fopen("gateway.log", "a");
            if (!gateway_log) {
                fprintf(stderr, "Error: Could not open gateway.log\n");
                pthread_mutex_unlock(&db_mutex);
                return NULL;
            }
        }
        fprintf(gateway_log, "- %s - Database file %s opened.\n",
                get_current_time_string(), filename);
        fflush(gateway_log);
    }

    pthread_mutex_unlock(&db_mutex);
    return db_file;
}

// Insert a sensor record into the database
int insert_sensor(sensor_id_t id, sensor_value_t value, sensor_ts_t ts) {
    pthread_mutex_lock(&db_mutex);
    if (!db_file) {
        fprintf(stderr, "Database file is not open.\n");
        pthread_mutex_unlock(&db_mutex);
        return -1;
    }

    // Write to database file
    fprintf(db_file, "%u, %.2f, %ld\n", id, value, ts);
    fflush(db_file); // Ensure data is written to disk immediately

    // Log insertion to gateway.log
    if (gateway_log) {
        fprintf(gateway_log, "- %s - Data insertion from sensor %u succeeded.\n",
                get_current_time_string(), id);
        fflush(gateway_log);
    } else {
        fprintf(stderr, "Gateway log file is not open.\n");
    }

    pthread_mutex_unlock(&db_mutex);
    return 0;
}

// Close the database file
int close_db() {
    pthread_mutex_lock(&db_mutex);
    if (!db_file) {
        fprintf(stderr, "Database file is not open.\n");
        pthread_mutex_unlock(&db_mutex);
        return -1;
    }

    fclose(db_file);
    db_file = NULL;

    // Close gateway log file
    if (gateway_log) {
        fprintf(gateway_log, "- %s - Database file closed.\n", get_current_time_string());
        fflush(gateway_log);
        fclose(gateway_log);
        gateway_log = NULL;
    }

    fprintf(stderr, "The data.csv file has been closed.\n");
    pthread_mutex_unlock(&db_mutex);
    return 0;
}

// Storage manager thread function
void *create_storagemgr(void *ptr) {
    sbuffer_t *buffer = (sbuffer_t *)ptr;
    if (!buffer) {
        fprintf(stderr, "Shared buffer is NULL.\n");
        pthread_exit(NULL);
    }

    // Open the database file
    if (!open_db("data.csv", false)) {
        fprintf(stderr, "Error: Failed to open database. Exiting storage manager thread.\n");
        pthread_exit(NULL);
    }

    sensor_data_t data;
    int result;

    while (1) {
        result = sbuffer_remove(buffer, &data);

        if (result == SBUFFER_NO_DATA) {
            // Check if the stream has ended
            if (sbuffer_is_stream_ended(buffer)) {
                printf("[Consumer] No more data to consume. Exiting...\n");
                break;
            }
            continue;
        }

        if (result == SBUFFER_SUCCESS) {
            insert_sensor(data.id, data.value, data.ts);
        }
    }

    close_db(); // Close the database file
    pthread_exit(NULL);
}
 */
/**
 *#include "sensor_db.h"
#include <pthread.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Shared database file pointer
static FILE *db_file = NULL;
static FILE *gateway_log = NULL; // Log file pointer for gateway.log

// Mutex for thread-safe file operations
static pthread_mutex_t db_mutex = PTHREAD_MUTEX_INITIALIZER;

// Function to get current time as a string
char *get_current_time_string() {
    static char time_str[32];
    time_t now = time(NULL);
    struct tm *tm_info = localtime(&now);
    strftime(time_str, sizeof(time_str), "%a %b %d %H:%M:%S %Y", tm_info);
    return time_str;
}

// Open the database file
FILE *open_db(char *filename, bool append) {
    pthread_mutex_lock(&db_mutex);
    if (append) {
        db_file = fopen(filename, "a");
    } else {
        db_file = fopen(filename, "w");
        if (db_file) {
            fprintf(stderr, "A new data.csv file has been created.\n");
        }
    }
    if (!db_file) {
        fprintf(stderr, "Error: Could not open the file %s\n", filename);
    }

    // Open gateway log file
    gateway_log = fopen("gateway.log", "a");
    if (!gateway_log) {
        fprintf(stderr, "Error: Could not open gateway.log\n");
    }

    pthread_mutex_unlock(&db_mutex);
    return db_file;
}

// Insert a sensor record into the database
int insert_sensor(sensor_id_t id, sensor_value_t value, sensor_ts_t ts) {
    pthread_mutex_lock(&db_mutex);
    if (!db_file) {
        fprintf(stderr, "Database file is not open.\n");
        pthread_mutex_unlock(&db_mutex);
        return -1;
    }

    // Write to database file
    fprintf(db_file, "%u, %.2f, %ld\n", id, value, ts);
    fflush(db_file); // Ensure data is written to disk immediately

    // Log insertion to gateway.log
    if (gateway_log) {
        fprintf(gateway_log, "- %s - Data insertion from sensor %u succeeded.\n",
                get_current_time_string(), id);
        fflush(gateway_log);
    } else {
        fprintf(stderr, "Gateway log file is not open.\n");
    }

    pthread_mutex_unlock(&db_mutex);
    return 0;
}

// Close the database file
int close_db() {
    pthread_mutex_lock(&db_mutex);
    if (!db_file) {
        fprintf(stderr, "Database file is not open.\n");
        pthread_mutex_unlock(&db_mutex);
        return -1;
    }

    fclose(db_file);
    db_file = NULL;

    // Close gateway log file
    if (gateway_log) {
        fclose(gateway_log);
        gateway_log = NULL;
    }

    fprintf(stderr, "The data.csv file has been closed.\n");
    pthread_mutex_unlock(&db_mutex);
    return 0;
}

// Storage manager thread function
void *create_storagemgr(void *ptr) {
    sbuffer_t *buffer = (sbuffer_t *)ptr;
    if (!buffer) {
        fprintf(stderr, "Shared buffer is NULL.\n");
        pthread_exit(NULL);
    }

    // Open the database file
    if (!open_db("data.csv", false)) {
        pthread_exit(NULL);
    }

    sensor_data_t data;
    int result;

    while (1) {
        result = sbuffer_remove(buffer, &data);

        if (result == SBUFFER_NO_DATA) {
            // Check if the stream has ended
            if (sbuffer_is_stream_ended(buffer)) {
                printf("[Consumer] No more data to consume. Exiting...\n");
                break;
            }
            continue;
        }

        if (result == SBUFFER_SUCCESS) {
            insert_sensor(data.id, data.value, data.ts);
        }
    }

    close_db(); // Close the database file
    pthread_exit(NULL);
}
 */
/**
 *
#include "sensor_db.h"
#include <pthread.h>
#include <stdbool.h>

// Shared database file pointer
static FILE *db_file = NULL;
// Mutex for thread-safe file operations
static pthread_mutex_t db_mutex = PTHREAD_MUTEX_INITIALIZER;

// Open the database file
FILE *open_db(char *filename, bool append) {
    pthread_mutex_lock(&db_mutex);
    if (append) {
        db_file = fopen(filename, "a");
    } else {
        db_file = fopen(filename, "w");
        if (db_file) {
            fprintf(stderr, "A new data.csv file has been created.\n");
        }
    }
    if (!db_file) {
        fprintf(stderr, "Error: Could not open the file %s\n", filename);
    }
    pthread_mutex_unlock(&db_mutex);
    return db_file;
}

// Insert a sensor record into the database
int insert_sensor(sensor_id_t id, sensor_value_t value, sensor_ts_t ts) {
    pthread_mutex_lock(&db_mutex);
    if (!db_file) {
        fprintf(stderr, "Database file is not open.\n");
        pthread_mutex_unlock(&db_mutex);
        return -1;
    }

    fprintf(db_file, "%u, %f, %ld\n", id, value, ts);
    fflush(db_file); // Ensure data is written to disk immediately
    fprintf(stderr, "Data insertion from sensor %u succeeded.\n", id);

    pthread_mutex_unlock(&db_mutex);
    return 0;
}

// Close the database file
int close_db() {
    pthread_mutex_lock(&db_mutex);
    if (!db_file) {
        fprintf(stderr, "Database file is not open.\n");
        pthread_mutex_unlock(&db_mutex);
        return -1;
    }

    fclose(db_file);
    db_file = NULL;
    fprintf(stderr, "The data.csv file has been closed.\n");
    pthread_mutex_unlock(&db_mutex);
    return 0;
}

// Storage manager thread function
void *create_storagemgr(void *ptr) {
    sbuffer_t *buffer = (sbuffer_t *)ptr;
    if (!buffer) {
        fprintf(stderr, "Shared buffer is NULL.\n");
        pthread_exit(NULL);
    }

    // Open the database file
    if (!open_db("data.csv", false)) {
        pthread_exit(NULL);
    }

    sensor_data_t data;
    int result;

   while (1) {
    result = sbuffer_remove(buffer, &data);
//when test new add
   if (result == SBUFFER_NO_DATA) {
    // 检查数据流是否结束
    if (sbuffer_is_stream_ended(buffer)) {
        printf("[Consumer] No more data to consume. Exiting...\n");
        break;
    }
    continue;
}

}


    close_db(); // Close the database file
    pthread_exit(NULL);
}

 */